<?php
/**
 * Plugin Name: Compliance Popup Notice
 * Description: Shows a popup on main page load notifying users of compliance with UK, US, and EU internet safety laws.
 * Version: 1.1
 * Author: Your Name
 */
// Default options
function cpnp_default_options() {
    return [
        'use_theme_styles' => false,
        'font_family' => 'Arial, sans-serif',
        'font_color' => '#000000',
        'cookie_enabled' => true,
        'ip_detection_enabled' => true, // Always enabled, no toggle
        'show_uk' => true,
        'show_us' => true,
        'show_eu' => true
    ];
}
function cpnp_get_options() {
    return wp_parse_args(get_option('cpnp_options'), cpnp_default_options());
}
add_action('admin_menu', 'cpnp_settings_menu');
function cpnp_settings_menu() {
    add_options_page('Compliance Popup Settings', 'Compliance Popup', 'manage_options', 'cpnp-settings', 'cpnp_settings_page');
}
function cpnp_settings_page() {
    if (isset($_POST['cpnp_save'])) {
        check_admin_referer('cpnp_settings_save');
        $options = [
            'use_theme_styles' => isset($_POST['use_theme_styles']),
            'font_family' => sanitize_text_field($_POST['font_family']),
            'font_color' => sanitize_hex_color($_POST['font_color']),
            'cookie_enabled' => isset($_POST['cookie_enabled']),
            'ip_detection_enabled' => isset($_POST['ip_detection_enabled']),
            'show_uk' => isset($_POST['show_uk']),
            'show_us' => isset($_POST['show_us']),
            'show_eu' => isset($_POST['show_eu'])
        ];
        update_option('cpnp_options', $options);
        echo '<div class="updated"><p>Settings saved.</p></div>';
    }
    $options = cpnp_get_options();
    
// Create underage page on plugin activation
register_activation_hook(__FILE__, 'cpnp_create_underage_page');
function cpnp_create_underage_page() {
    $page_title = 'Underage';
    $page_content = '<div class="cpnp-underage-message"><h2>Access Denied</h2><p>Sorry, this website is only intended for an audience of 18 years or older. Feel free to return when you are of age!</p></div>';
    $page = get_page_by_title($page_title);
    if (!$page) {
        wp_insert_post([
            'post_title'   => $page_title,
            'post_content' => $page_content,
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_author'  => get_current_user_id(),
            'post_excerpt' => '',
            'comment_status' => 'closed',
            'ping_status' => 'closed',
            'post_category' => []
            'post_status'  => 'publish',
            'post_type'    => 'page'
        ]);
    }
}

// Add custom style for the underage message
add_action('wp_head', 'cpnp_add_custom_styles');
function cpnp_add_custom_styles() {
    echo '<style>
        .cpnp-underage-message {
            max-width: 700px;
            margin: 40px auto;
            padding: 30px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.2);
            text-align: center;
            font-family: inherit;
            color: inherit;
        }
        .cpnp-underage-message h2 {
            color: #dc3545;
        }
    </style>';
}
?>

    <div class="wrap">
        <h2>Compliance Popup Settings</h2>
        <form method="post">
            <?php wp_nonce_field('cpnp_settings_save'); 
// Create underage page on plugin activation
register_activation_hook(__FILE__, 'cpnp_create_underage_page');
function cpnp_create_underage_page() {
    $page_title = 'Underage';
    $page_content = '<div class="cpnp-underage-message"><h2>Access Denied</h2><p>Sorry, this website is only intended for an audience of 18 years or older. Feel free to return when you are of age!</p></div>';
    $page = get_page_by_title($page_title);
    if (!$page) {
        wp_insert_post([
            'post_title'   => $page_title,
            'post_content' => $page_content,
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_author'  => get_current_user_id(),
            'post_excerpt' => '',
            'comment_status' => 'closed',
            'ping_status' => 'closed',
            'post_category' => []
            'post_status'  => 'publish',
            'post_type'    => 'page'
        ]);
    }
}

// Add custom style for the underage message
add_action('wp_head', 'cpnp_add_custom_styles');
function cpnp_add_custom_styles() {
    echo '<style>
        .cpnp-underage-message {
            max-width: 700px;
            margin: 40px auto;
            padding: 30px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.2);
            text-align: center;
            font-family: inherit;
            color: inherit;
        }
        .cpnp-underage-message h2 {
            color: #dc3545;
        }
    </style>';
}
?>

            <table class="form-table">
                <tr><th>Use Theme Styling</th><td><input type="checkbox" name="use_theme_styles" <?php checked($options['use_theme_styles']); 
// Create underage page on plugin activation
register_activation_hook(__FILE__, 'cpnp_create_underage_page');
function cpnp_create_underage_page() {
    $page_title = 'Underage';
    $page_content = '<div class="cpnp-underage-message"><h2>Access Denied</h2><p>Sorry, this website is only intended for an audience of 18 years or older. Feel free to return when you are of age!</p></div>';
    $page = get_page_by_title($page_title);
    if (!$page) {
        wp_insert_post([
            'post_title'   => $page_title,
            'post_content' => $page_content,
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_author'  => get_current_user_id(),
            'post_excerpt' => '',
            'comment_status' => 'closed',
            'ping_status' => 'closed',
            'post_category' => []
            'post_status'  => 'publish',
            'post_type'    => 'page'
        ]);
    }
}

// Add custom style for the underage message
add_action('wp_head', 'cpnp_add_custom_styles');
function cpnp_add_custom_styles() {
    echo '<style>
        .cpnp-underage-message {
            max-width: 700px;
            margin: 40px auto;
            padding: 30px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.2);
            text-align: center;
            font-family: inherit;
            color: inherit;
        }
        .cpnp-underage-message h2 {
            color: #dc3545;
        }
    </style>';
}
?>
></td></tr>
                <tr><th>Font Family</th><td><input type="text" name="font_family" value="<?php echo esc_attr($options['font_family']); 
// Create underage page on plugin activation
register_activation_hook(__FILE__, 'cpnp_create_underage_page');
function cpnp_create_underage_page() {
    $page_title = 'Underage';
    $page_content = '<div class="cpnp-underage-message"><h2>Access Denied</h2><p>Sorry, this website is only intended for an audience of 18 years or older. Feel free to return when you are of age!</p></div>';
    $page = get_page_by_title($page_title);
    if (!$page) {
        wp_insert_post([
            'post_title'   => $page_title,
            'post_content' => $page_content,
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_author'  => get_current_user_id(),
            'post_excerpt' => '',
            'comment_status' => 'closed',
            'ping_status' => 'closed',
            'post_category' => []
            'post_status'  => 'publish',
            'post_type'    => 'page'
        ]);
    }
}

// Add custom style for the underage message
add_action('wp_head', 'cpnp_add_custom_styles');
function cpnp_add_custom_styles() {
    echo '<style>
        .cpnp-underage-message {
            max-width: 700px;
            margin: 40px auto;
            padding: 30px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.2);
            text-align: center;
            font-family: inherit;
            color: inherit;
        }
        .cpnp-underage-message h2 {
            color: #dc3545;
        }
    </style>';
}
?>
"></td></tr>
                <tr><th>Font Color</th><td><input type="color" name="font_color" value="<?php echo esc_attr($options['font_color']); 
// Create underage page on plugin activation
register_activation_hook(__FILE__, 'cpnp_create_underage_page');
function cpnp_create_underage_page() {
    $page_title = 'Underage';
    $page_content = '<div class="cpnp-underage-message"><h2>Access Denied</h2><p>Sorry, this website is only intended for an audience of 18 years or older. Feel free to return when you are of age!</p></div>';
    $page = get_page_by_title($page_title);
    if (!$page) {
        wp_insert_post([
            'post_title'   => $page_title,
            'post_content' => $page_content,
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_author'  => get_current_user_id(),
            'post_excerpt' => '',
            'comment_status' => 'closed',
            'ping_status' => 'closed',
            'post_category' => []
            'post_status'  => 'publish',
            'post_type'    => 'page'
        ]);
    }
}

// Add custom style for the underage message
add_action('wp_head', 'cpnp_add_custom_styles');
function cpnp_add_custom_styles() {
    echo '<style>
        .cpnp-underage-message {
            max-width: 700px;
            margin: 40px auto;
            padding: 30px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.2);
            text-align: center;
            font-family: inherit;
            color: inherit;
        }
        .cpnp-underage-message h2 {
            color: #dc3545;
        }
    </style>';
}
?>
"></td></tr>
                <tr><th>Enable Cookie</th><td><input type="checkbox" name="cookie_enabled" <?php checked($options['cookie_enabled']); 
// Create underage page on plugin activation
register_activation_hook(__FILE__, 'cpnp_create_underage_page');
function cpnp_create_underage_page() {
    $page_title = 'Underage';
    $page_content = '<div class="cpnp-underage-message"><h2>Access Denied</h2><p>Sorry, this website is only intended for an audience of 18 years or older. Feel free to return when you are of age!</p></div>';
    $page = get_page_by_title($page_title);
    if (!$page) {
        wp_insert_post([
            'post_title'   => $page_title,
            'post_content' => $page_content,
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_author'  => get_current_user_id(),
            'post_excerpt' => '',
            'comment_status' => 'closed',
            'ping_status' => 'closed',
            'post_category' => []
            'post_status'  => 'publish',
            'post_type'    => 'page'
        ]);
    }
}

// Add custom style for the underage message
add_action('wp_head', 'cpnp_add_custom_styles');
function cpnp_add_custom_styles() {
    echo '<style>
        .cpnp-underage-message {
            max-width: 700px;
            margin: 40px auto;
            padding: 30px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.2);
            text-align: center;
            font-family: inherit;
            color: inherit;
        }
        .cpnp-underage-message h2 {
            color: #dc3545;
        }
    </style>';
}
?>
></td></tr>
                                <tr><th>Show UK Compliance</th><td><input type="checkbox" name="show_uk" <?php checked($options['show_uk']); 
// Create underage page on plugin activation
register_activation_hook(__FILE__, 'cpnp_create_underage_page');
function cpnp_create_underage_page() {
    $page_title = 'Underage';
    $page_content = '<div class="cpnp-underage-message"><h2>Access Denied</h2><p>Sorry, this website is only intended for an audience of 18 years or older. Feel free to return when you are of age!</p></div>';
    $page = get_page_by_title($page_title);
    if (!$page) {
        wp_insert_post([
            'post_title'   => $page_title,
            'post_content' => $page_content,
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_author'  => get_current_user_id(),
            'post_excerpt' => '',
            'comment_status' => 'closed',
            'ping_status' => 'closed',
            'post_category' => []
            'post_status'  => 'publish',
            'post_type'    => 'page'
        ]);
    }
}

// Add custom style for the underage message
add_action('wp_head', 'cpnp_add_custom_styles');
function cpnp_add_custom_styles() {
    echo '<style>
        .cpnp-underage-message {
            max-width: 700px;
            margin: 40px auto;
            padding: 30px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.2);
            text-align: center;
            font-family: inherit;
            color: inherit;
        }
        .cpnp-underage-message h2 {
            color: #dc3545;
        }
    </style>';
}
?>
></td></tr>
                <tr><th>Show US Compliance</th><td><input type="checkbox" name="show_us" <?php checked($options['show_us']); 
// Create underage page on plugin activation
register_activation_hook(__FILE__, 'cpnp_create_underage_page');
function cpnp_create_underage_page() {
    $page_title = 'Underage';
    $page_content = '<div class="cpnp-underage-message"><h2>Access Denied</h2><p>Sorry, this website is only intended for an audience of 18 years or older. Feel free to return when you are of age!</p></div>';
    $page = get_page_by_title($page_title);
    if (!$page) {
        wp_insert_post([
            'post_title'   => $page_title,
            'post_content' => $page_content,
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_author'  => get_current_user_id(),
            'post_excerpt' => '',
            'comment_status' => 'closed',
            'ping_status' => 'closed',
            'post_category' => []
            'post_status'  => 'publish',
            'post_type'    => 'page'
        ]);
    }
}

// Add custom style for the underage message
add_action('wp_head', 'cpnp_add_custom_styles');
function cpnp_add_custom_styles() {
    echo '<style>
        .cpnp-underage-message {
            max-width: 700px;
            margin: 40px auto;
            padding: 30px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.2);
            text-align: center;
            font-family: inherit;
            color: inherit;
        }
        .cpnp-underage-message h2 {
            color: #dc3545;
        }
    </style>';
}
?>
></td></tr>
                <tr><th>Show EU Compliance (GDPR)</th><td><input type="checkbox" name="show_eu" <?php checked($options['show_eu']); 
// Create underage page on plugin activation
register_activation_hook(__FILE__, 'cpnp_create_underage_page');
function cpnp_create_underage_page() {
    $page_title = 'Underage';
    $page_content = '<div class="cpnp-underage-message"><h2>Access Denied</h2><p>Sorry, this website is only intended for an audience of 18 years or older. Feel free to return when you are of age!</p></div>';
    $page = get_page_by_title($page_title);
    if (!$page) {
        wp_insert_post([
            'post_title'   => $page_title,
            'post_content' => $page_content,
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_author'  => get_current_user_id(),
            'post_excerpt' => '',
            'comment_status' => 'closed',
            'ping_status' => 'closed',
            'post_category' => []
            'post_status'  => 'publish',
            'post_type'    => 'page'
        ]);
    }
}

// Add custom style for the underage message
add_action('wp_head', 'cpnp_add_custom_styles');
function cpnp_add_custom_styles() {
    echo '<style>
        .cpnp-underage-message {
            max-width: 700px;
            margin: 40px auto;
            padding: 30px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.2);
            text-align: center;
            font-family: inherit;
            color: inherit;
        }
        .cpnp-underage-message h2 {
            color: #dc3545;
        }
    </style>';
}
?>
></td></tr>
            </table>
            <p><input type="submit" name="cpnp_save" class="button-primary" value="Save Changes"></p>
        </form>
    </div>
    <?php
}
add_action('wp_footer', 'cpnp_display_popup');
function cpnp_display_popup() {
    if (!is_front_page()) return;
    $options = cpnp_get_options();
    if ($options['cookie_enabled'] && isset($_COOKIE['cpnp_acknowledged'])) return;
    $messages = [];
    if ($options['show_uk']) $messages[] = "UK Digital Economy Act and Online Safety Bill";
    if ($options['show_us']) $messages[] = "US regulations such as COPPA and Section 230 CDA";
    if ($options['show_eu']) $messages[] = "EU GDPR compliance";
    $message_string = implode(', ', $messages);
    $font_style = $options['use_theme_styles'] ? '' : "font-family: {$options['font_family']}; color: {$options['font_color']};";
    
// Create underage page on plugin activation
register_activation_hook(__FILE__, 'cpnp_create_underage_page');
function cpnp_create_underage_page() {
    $page_title = 'Underage';
    $page_content = '<div class="cpnp-underage-message"><h2>Access Denied</h2><p>Sorry, this website is only intended for an audience of 18 years or older. Feel free to return when you are of age!</p></div>';
    $page = get_page_by_title($page_title);
    if (!$page) {
        wp_insert_post([
            'post_title'   => $page_title,
            'post_content' => $page_content,
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_author'  => get_current_user_id(),
            'post_excerpt' => '',
            'comment_status' => 'closed',
            'ping_status' => 'closed',
            'post_category' => []
            'post_status'  => 'publish',
            'post_type'    => 'page'
        ]);
    }
}

// Add custom style for the underage message
add_action('wp_head', 'cpnp_add_custom_styles');
function cpnp_add_custom_styles() {
    echo '<style>
        .cpnp-underage-message {
            max-width: 700px;
            margin: 40px auto;
            padding: 30px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.2);
            text-align: center;
            font-family: inherit;
            color: inherit;
        }
        .cpnp-underage-message h2 {
            color: #dc3545;
        }
    </style>';
}
?>

    <div id="compliance-popup" style="display:none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.6); z-index: 9999; align-items: center; justify-content: center;">
        <div class="popup-content" style="background: white; padding: 20px; border-radius: 10px; max-width: 500px; margin: auto; text-align: center; <?php echo $font_style; 
// Create underage page on plugin activation
register_activation_hook(__FILE__, 'cpnp_create_underage_page');
function cpnp_create_underage_page() {
    $page_title = 'Underage';
    $page_content = '<div class="cpnp-underage-message"><h2>Access Denied</h2><p>Sorry, this website is only intended for an audience of 18 years or older. Feel free to return when you are of age!</p></div>';
    $page = get_page_by_title($page_title);
    if (!$page) {
        wp_insert_post([
            'post_title'   => $page_title,
            'post_content' => $page_content,
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_author'  => get_current_user_id(),
            'post_excerpt' => '',
            'comment_status' => 'closed',
            'ping_status' => 'closed',
            'post_category' => []
            'post_status'  => 'publish',
            'post_type'    => 'page'
        ]);
    }
}

// Add custom style for the underage message
add_action('wp_head', 'cpnp_add_custom_styles');
function cpnp_add_custom_styles() {
    echo '<style>
        .cpnp-underage-message {
            max-width: 700px;
            margin: 40px auto;
            padding: 30px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.2);
            text-align: center;
            font-family: inherit;
            color: inherit;
        }
        .cpnp-underage-message h2 {
            color: #dc3545;
        }
    </style>';
}
?>
">
            <h2>Compliance Notice</h2>
            <p>This website contains age-restricted materials including nudity and explicit depictions of sexual activity. By entering, you affirm that you are at least 18 years of age or the age of majority in the jurisdiction you are accessing the website from and you consent to viewing sexually explicit content.</p>
            <p id="compliance-text" style="margin-top: 10px;"><strong><?php echo esc_html($message_string); 
// Create underage page on plugin activation
register_activation_hook(__FILE__, 'cpnp_create_underage_page');
function cpnp_create_underage_page() {
    $page_title = 'Underage';
    $page_content = '<div class="cpnp-underage-message"><h2>Access Denied</h2><p>Sorry, this website is only intended for an audience of 18 years or older. Feel free to return when you are of age!</p></div>';
    $page = get_page_by_title($page_title);
    if (!$page) {
        wp_insert_post([
            'post_title'   => $page_title,
            'post_content' => $page_content,
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_author'  => get_current_user_id(),
            'post_excerpt' => '',
            'comment_status' => 'closed',
            'ping_status' => 'closed',
            'post_category' => []
            'post_status'  => 'publish',
            'post_type'    => 'page'
        ]);
    }
}

// Add custom style for the underage message
add_action('wp_head', 'cpnp_add_custom_styles');
function cpnp_add_custom_styles() {
    echo '<style>
        .cpnp-underage-message {
            max-width: 700px;
            margin: 40px auto;
            padding: 30px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.2);
            text-align: center;
            font-family: inherit;
            color: inherit;
        }
        .cpnp-underage-message h2 {
            color: #dc3545;
        }
    </style>';
}
?>
</strong></p>
            <div style="margin-top: 15px;">
                <button onclick="acknowledgeCompliancePopup()" style="padding:10px 20px;margin-right:10px;background:#28a745;color:white;border:none;border-radius:5px;cursor:pointer;">I am 18 or older - Enter</button>
                <button onclick="redirectUnderageUser()" style="padding:10px 20px;background:#dc3545;color:white;border:none;border-radius:5px;cursor:pointer;">I am under 18 - Exit</button>
            </div>
            <button onclick="acknowledgeCompliancePopup()" style="margin-top:15px;padding:10px 20px;background:#0073aa;color:white;border:none;border-radius:5px;cursor:pointer;">OK, Got it</button>
        </div>
    </div>
    <script>
        function acknowledgeCompliancePopup() {
            document.cookie = "cpnp_acknowledged=true; path=/; max-age=31536000";
            document.getElementById('compliance-popup').style.display = 'none';
        }
        function redirectUnderageUser() {
            window.location.href = "/underage"; // Placeholder page
            document.getElementById('compliance-popup').style.display = 'none';
            <?php if ($options['cookie_enabled']): 
// Create underage page on plugin activation
register_activation_hook(__FILE__, 'cpnp_create_underage_page');
function cpnp_create_underage_page() {
    $page_title = 'Underage';
    $page_content = '<div class="cpnp-underage-message"><h2>Access Denied</h2><p>Sorry, this website is only intended for an audience of 18 years or older. Feel free to return when you are of age!</p></div>';
    $page = get_page_by_title($page_title);
    if (!$page) {
        wp_insert_post([
            'post_title'   => $page_title,
            'post_content' => $page_content,
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_author'  => get_current_user_id(),
            'post_excerpt' => '',
            'comment_status' => 'closed',
            'ping_status' => 'closed',
            'post_category' => []
            'post_status'  => 'publish',
            'post_type'    => 'page'
        ]);
    }
}

// Add custom style for the underage message
add_action('wp_head', 'cpnp_add_custom_styles');
function cpnp_add_custom_styles() {
    echo '<style>
        .cpnp-underage-message {
            max-width: 700px;
            margin: 40px auto;
            padding: 30px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.2);
            text-align: center;
            font-family: inherit;
            color: inherit;
        }
        .cpnp-underage-message h2 {
            color: #dc3545;
        }
    </style>';
}
?>

            document.cookie = "cpnp_acknowledged=true; path=/; max-age=31536000";
            <?php endif; 
// Create underage page on plugin activation
register_activation_hook(__FILE__, 'cpnp_create_underage_page');
function cpnp_create_underage_page() {
    $page_title = 'Underage';
    $page_content = '<div class="cpnp-underage-message"><h2>Access Denied</h2><p>Sorry, this website is only intended for an audience of 18 years or older. Feel free to return when you are of age!</p></div>';
    $page = get_page_by_title($page_title);
    if (!$page) {
        wp_insert_post([
            'post_title'   => $page_title,
            'post_content' => $page_content,
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_author'  => get_current_user_id(),
            'post_excerpt' => '',
            'comment_status' => 'closed',
            'ping_status' => 'closed',
            'post_category' => []
            'post_status'  => 'publish',
            'post_type'    => 'page'
        ]);
    }
}

// Add custom style for the underage message
add_action('wp_head', 'cpnp_add_custom_styles');
function cpnp_add_custom_styles() {
    echo '<style>
        .cpnp-underage-message {
            max-width: 700px;
            margin: 40px auto;
            padding: 30px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.2);
            text-align: center;
            font-family: inherit;
            color: inherit;
        }
        .cpnp-underage-message h2 {
            color: #dc3545;
        }
    </style>';
}
?>

        }
        document.addEventListener('DOMContentLoaded', function() {
            <?php if ($options['ip_detection_enabled']): 
// Create underage page on plugin activation
register_activation_hook(__FILE__, 'cpnp_create_underage_page');
function cpnp_create_underage_page() {
    $page_title = 'Underage';
    $page_content = '<div class="cpnp-underage-message"><h2>Access Denied</h2><p>Sorry, this website is only intended for an audience of 18 years or older. Feel free to return when you are of age!</p></div>';
    $page = get_page_by_title($page_title);
    if (!$page) {
        wp_insert_post([
            'post_title'   => $page_title,
            'post_content' => $page_content,
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_author'  => get_current_user_id(),
            'post_excerpt' => '',
            'comment_status' => 'closed',
            'ping_status' => 'closed',
            'post_category' => []
            'post_status'  => 'publish',
            'post_type'    => 'page'
        ]);
    }
}

// Add custom style for the underage message
add_action('wp_head', 'cpnp_add_custom_styles');
function cpnp_add_custom_styles() {
    echo '<style>
        .cpnp-underage-message {
            max-width: 700px;
            margin: 40px auto;
            padding: 30px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.2);
            text-align: center;
            font-family: inherit;
            color: inherit;
        }
        .cpnp-underage-message h2 {
            color: #dc3545;
        }
    </style>';
}
?>

            fetch('https://ipapi.co/json/')
                .then(response => response.json())
                .then(data => {
                    const country = data.country_code;
                    if ((<?php echo json_encode($options['show_uk']); 
// Create underage page on plugin activation
register_activation_hook(__FILE__, 'cpnp_create_underage_page');
function cpnp_create_underage_page() {
    $page_title = 'Underage';
    $page_content = '<div class="cpnp-underage-message"><h2>Access Denied</h2><p>Sorry, this website is only intended for an audience of 18 years or older. Feel free to return when you are of age!</p></div>';
    $page = get_page_by_title($page_title);
    if (!$page) {
        wp_insert_post([
            'post_title'   => $page_title,
            'post_content' => $page_content,
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_author'  => get_current_user_id(),
            'post_excerpt' => '',
            'comment_status' => 'closed',
            'ping_status' => 'closed',
            'post_category' => []
            'post_status'  => 'publish',
            'post_type'    => 'page'
        ]);
    }
}

// Add custom style for the underage message
add_action('wp_head', 'cpnp_add_custom_styles');
function cpnp_add_custom_styles() {
    echo '<style>
        .cpnp-underage-message {
            max-width: 700px;
            margin: 40px auto;
            padding: 30px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.2);
            text-align: center;
            font-family: inherit;
            color: inherit;
        }
        .cpnp-underage-message h2 {
            color: #dc3545;
        }
    </style>';
}
?>
 && country === 'GB') ||
                        (<?php echo json_encode($options['show_us']); 
// Create underage page on plugin activation
register_activation_hook(__FILE__, 'cpnp_create_underage_page');
function cpnp_create_underage_page() {
    $page_title = 'Underage';
    $page_content = '<div class="cpnp-underage-message"><h2>Access Denied</h2><p>Sorry, this website is only intended for an audience of 18 years or older. Feel free to return when you are of age!</p></div>';
    $page = get_page_by_title($page_title);
    if (!$page) {
        wp_insert_post([
            'post_title'   => $page_title,
            'post_content' => $page_content,
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_author'  => get_current_user_id(),
            'post_excerpt' => '',
            'comment_status' => 'closed',
            'ping_status' => 'closed',
            'post_category' => []
            'post_status'  => 'publish',
            'post_type'    => 'page'
        ]);
    }
}

// Add custom style for the underage message
add_action('wp_head', 'cpnp_add_custom_styles');
function cpnp_add_custom_styles() {
    echo '<style>
        .cpnp-underage-message {
            max-width: 700px;
            margin: 40px auto;
            padding: 30px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.2);
            text-align: center;
            font-family: inherit;
            color: inherit;
        }
        .cpnp-underage-message h2 {
            color: #dc3545;
        }
    </style>';
}
?>
 && country === 'US') ||
                        (<?php echo json_encode($options['show_eu']); 
// Create underage page on plugin activation
register_activation_hook(__FILE__, 'cpnp_create_underage_page');
function cpnp_create_underage_page() {
    $page_title = 'Underage';
    $page_content = '<div class="cpnp-underage-message"><h2>Access Denied</h2><p>Sorry, this website is only intended for an audience of 18 years or older. Feel free to return when you are of age!</p></div>';
    $page = get_page_by_title($page_title);
    if (!$page) {
        wp_insert_post([
            'post_title'   => $page_title,
            'post_content' => $page_content,
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_author'  => get_current_user_id(),
            'post_excerpt' => '',
            'comment_status' => 'closed',
            'ping_status' => 'closed',
            'post_category' => []
            'post_status'  => 'publish',
            'post_type'    => 'page'
        ]);
    }
}

// Add custom style for the underage message
add_action('wp_head', 'cpnp_add_custom_styles');
function cpnp_add_custom_styles() {
    echo '<style>
        .cpnp-underage-message {
            max-width: 700px;
            margin: 40px auto;
            padding: 30px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.2);
            text-align: center;
            font-family: inherit;
            color: inherit;
        }
        .cpnp-underage-message h2 {
            color: #dc3545;
        }
    </style>';
}
?>
 && ['DE','FR','ES','IT','NL','PL','SE','BE','AT','IE','PT','GR'].includes(country))) {
                        document.getElementById('compliance-popup').style.display = 'flex';
                    }
                })
                .catch(() => document.getElementById('compliance-popup').style.display = 'flex');
            <?php else: 
// Create underage page on plugin activation
register_activation_hook(__FILE__, 'cpnp_create_underage_page');
function cpnp_create_underage_page() {
    $page_title = 'Underage';
    $page_content = '<div class="cpnp-underage-message"><h2>Access Denied</h2><p>Sorry, this website is only intended for an audience of 18 years or older. Feel free to return when you are of age!</p></div>';
    $page = get_page_by_title($page_title);
    if (!$page) {
        wp_insert_post([
            'post_title'   => $page_title,
            'post_content' => $page_content,
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_author'  => get_current_user_id(),
            'post_excerpt' => '',
            'comment_status' => 'closed',
            'ping_status' => 'closed',
            'post_category' => []
            'post_status'  => 'publish',
            'post_type'    => 'page'
        ]);
    }
}

// Add custom style for the underage message
add_action('wp_head', 'cpnp_add_custom_styles');
function cpnp_add_custom_styles() {
    echo '<style>
        .cpnp-underage-message {
            max-width: 700px;
            margin: 40px auto;
            padding: 30px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.2);
            text-align: center;
            font-family: inherit;
            color: inherit;
        }
        .cpnp-underage-message h2 {
            color: #dc3545;
        }
    </style>';
}
?>

            document.getElementById('compliance-popup').style.display = 'flex';
            <?php endif; 
// Create underage page on plugin activation
register_activation_hook(__FILE__, 'cpnp_create_underage_page');
function cpnp_create_underage_page() {
    $page_title = 'Underage';
    $page_content = '<div class="cpnp-underage-message"><h2>Access Denied</h2><p>Sorry, this website is only intended for an audience of 18 years or older. Feel free to return when you are of age!</p></div>';
    $page = get_page_by_title($page_title);
    if (!$page) {
        wp_insert_post([
            'post_title'   => $page_title,
            'post_content' => $page_content,
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_author'  => get_current_user_id(),
            'post_excerpt' => '',
            'comment_status' => 'closed',
            'ping_status' => 'closed',
            'post_category' => []
            'post_status'  => 'publish',
            'post_type'    => 'page'
        ]);
    }
}

// Add custom style for the underage message
add_action('wp_head', 'cpnp_add_custom_styles');
function cpnp_add_custom_styles() {
    echo '<style>
        .cpnp-underage-message {
            max-width: 700px;
            margin: 40px auto;
            padding: 30px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.2);
            text-align: center;
            font-family: inherit;
            color: inherit;
        }
        .cpnp-underage-message h2 {
            color: #dc3545;
        }
    </style>';
}
?>

        });
    </script>
    <?php
} 
// Create underage page on plugin activation
register_activation_hook(__FILE__, 'cpnp_create_underage_page');
function cpnp_create_underage_page() {
    $page_title = 'Underage';
    $page_content = '<div class="cpnp-underage-message"><h2>Access Denied</h2><p>Sorry, this website is only intended for an audience of 18 years or older. Feel free to return when you are of age!</p></div>';
    $page = get_page_by_title($page_title);
    if (!$page) {
        wp_insert_post([
            'post_title'   => $page_title,
            'post_content' => $page_content,
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_author'  => get_current_user_id(),
            'post_excerpt' => '',
            'comment_status' => 'closed',
            'ping_status' => 'closed',
            'post_category' => []
            'post_status'  => 'publish',
            'post_type'    => 'page'
        ]);
    }
}

// Add custom style for the underage message
add_action('wp_head', 'cpnp_add_custom_styles');
function cpnp_add_custom_styles() {
    echo '<style>
        .cpnp-underage-message {
            max-width: 700px;
            margin: 40px auto;
            padding: 30px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.2);
            text-align: center;
            font-family: inherit;
            color: inherit;
        }
        .cpnp-underage-message h2 {
            color: #dc3545;
        }
    </style>';
}
?>

